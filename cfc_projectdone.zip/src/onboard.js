import React,{useState,useRef, useEffect} from "react";
import Button from 'react-bootstrap/Button';
import Header from "./header";
import Table from 'react-bootstrap/Table';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Nav from 'react-bootstrap/Nav';
import { useNavigate } from "react-router-dom";
import { FaPlus,FaUserAlt} from "react-icons/fa";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';
import onBoard_image from './assets/onBoard_image.jpg';

export default function Onboard(){

    var navigate = useNavigate();

    return(
        <>
            
            <Header />

            <div>
                <h2>OnBoard Image</h2>
            </div>
            &nbsp;
            

        </>
    )
}
