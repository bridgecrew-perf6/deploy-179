import React,{useState,useRef} from "react";
import Button from 'react-bootstrap/Button';
import Header from "./header";
import Table from 'react-bootstrap/Table';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Nav from 'react-bootstrap/Nav';
import { useNavigate } from "react-router-dom";
import { FaPlus,FaUserAlt} from "react-icons/fa";
import Refer_price_bar from "./refer_bar";
import './assets/css/referrals.css';

export default function Referrals(){

    var navigate = useNavigate();

    var dataMain = [
        {
            id : "01",
            name:"Fredick",
            login_streak:"28",
            coin_earned : "35",
        },
        {
            id : "02",
            name:"Deepak Mishra",
            login_streak:"35",
            coin_earned : "35",
        },
        {
            id : "03",
            name:"Michael",
            login_streak:"49",
            coin_earned : "35",
        },
        {
            id : "04",
            name:"Triple H",
            login_streak:"56",
            coin_earned : "35",
        },
        {
            id : "05",
            name:"Shawn the sheep",
            login_streak:"96",
            coin_earned : "35",
        },
        
    ];

    return(
        <>
            
            <Header />

            <div>
                <h2 className="textHeader">Referrals</h2>
            </div>
            &nbsp;
            <Refer_price_bar />
            &nbsp;

        <div style={{marginTop:30,display:'flex'}}>

            <div style={{width:'50%'}}>
            <small className="label text-dark" style={{fontSize:20}}>
            Your Referrals
            </small>
            </div>

            <div style={{width:'50%',display:"flex",justifyContent:'flex-end'}}>
            <small style={{fontSize:20,opacity:0.9}}>
            <div style={{flexDirection:'row'}}>
            <small style={{opacity:0.7}}>Filter By</small>
            <Button style={{marginLeft:20,borderWidth:0}} className="btn btn-outline-info bg-white">Active</Button>
        </div>
        </small>
        </div>

        </div>

        <div>

        &nbsp;

<div className="table_Data">

        <div className="table_items_1">
                <label className="label" style={{fontSize:20,color:'#aaaaaa'}}>#</label>
        </div>

        <div className="table_items_2">
                <label className="label" style={{fontSize:20,color:'#aaaaaa'}}>Name</label>
        </div>

        <div className="table_items_3">
                <label className="label"  style={{fontSize:20,color:'#aaaaaa'}}>Login Streak</label>
        </div>

        <div className="table_items_4">
                <label className="label" style={{fontSize:20,color:'#aaaaaa'}}>Coin Earned</label>
        </div>

        <div className="table_items_5">
                <label></label>
        </div>

</div>

&nbsp;

{dataMain.map((val,index)=><div className="table_Data_Item">

        <div className="table_items_1">
                <label className="label" style={{fontSize:20}}>{val.id}</label>
        </div>

        <div className="table_items_2">
                <label className="label" style={{fontSize:20}}>{val.name}</label>
        </div>

        <div className="table_items_3">
                <label className="label"  style={{fontSize:20}}>{val.login_streak}</label>
        </div>

        <div className="table_items_4">
                <label className="label" style={{fontSize:20}}>{val.coin_earned}</label>
        </div>

        <div style={{display:'flex',justifyContent:"flex-end"}} className="table_items_5">
        <label className="label" style={{color:'#14A9FF',marginRight:20}}>View Profile</label>
        </div>

</div>)}

        {/* <Table>

  <tbody>

    <tr className="text-center border ">
      <td style={{opacity:'0.5'}}>#</td>
      <td style={{opacity:'0.5'}}>Name</td>
      <td style={{opacity:'0.5'}}>Login Streak</td>
      <td style={{opacity:'0.5'}}>Coin Earned</td>
      <td style={{opacity:'0.5'}}></td>
    </tr>

        {dataMain.map((val,index)=><tr className="text-center">
      <td style={{opacity:'0.5'}}>{val.id}</td>
      <td style={{opacity:'0.5'}}>{val.name}</td>
      <td style={{opacity:'0.5'}}>{val.login_streak}</td>
      <td style={{opacity:'0.5'}}>{val.coin_earned}</td>
      <td>
      <Button style={{backgroundColor:'#14A9FF',borderColor:'#14A9FF'}}><FaUserAlt size={15} color="white" /><small style={{marginLeft:10}}>View Profile</small></Button> 
      </td>
    </tr>
        )}

  </tbody>
</Table> */}

        </div>

        </>
    )
}