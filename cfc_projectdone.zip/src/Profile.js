import React,{useState,useRef, useEffect} from "react";
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import Navbar from 'react-bootstrap/Navbar';
import { useNavigate } from "react-router-dom";
import { FaPlus,FaUserAlt,FaCoins,FaUserFriends} from "react-icons/fa";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip,ResponsiveContainer } from 'recharts';
import Image from "react-bootstrap/Image";
import Form from 'react-bootstrap/Form';
import Container from 'react-bootstrap/Container';
import Header from "./header";
import './assets/css/profile.css';

function Profile() {
  return (
    <div className="body">
     <Header />
    &nbsp;
    <div className="Profile_icon">

        <div className="item_1">
            <div className="profile_img">

            </div>
        </div>

        <div className="item_2">
            
            <div>

                <div>
                    <label className="label" style={{fontSize:30}}>Julia michael</label>
                    
                </div>
                <small style={{color:'#AAAAAA'}}>LA,CA,US</small>
            </div>

        </div>

        <div className="item_3">

        <div className="viewAllTag">
        <label className="view_all_text">Edit Profile</label>
      </div>
        </div>

        <div className="item_4">
        <small>Icon Needed</small>
        </div>

    </div>
    &nbsp;
    <div className="about_section">

    <div className="about_section_details">
      <div className="mainDataTable">
        <label style={{fontSize:32}} className="label">About</label>
        &nbsp;
        <label style={{color:'#aaaaaa'}}>Cupidatat laboris minim cillum adipisicing ea enim incididunt. Nulla voluptate non aliqua velit dolor in ea reprehenderit culpa mollit. Velit reprehenderit minim dolor ex tempor do id sunt cupidatat. In Lorem ad pariatur ut adipisicing.</label>
        &nbsp;
        <div className="contact_details">

        <div className="contact_details_items">
        <label className="label">1 August 2006</label>
      </div>

      <div className="contact_details_items">
        <label className="label">+03213545613</label>
      </div>

      <div className="contact_details_items">
        <label className="label">ldclsd76@gmail.com</label>
      </div>

        </div>

      </div>
    </div>
    
    <div className="about_section_icons">
    <div className="mainDataTable">
      <FaUserFriends size={20} color="#95a5a6" /> 
      </div>
  </div>
    
    </div>

    &nbsp;
    <div className="activity_section">

    <div className="activity_section_details">
      <div className="mainDataTable">
        <label style={{fontSize:32,marginBottom:20}} className="label">Activity</label>
        
        <div className="contact_details">

        <div className="activity_details">
          <div>
            <label style={{color:'#aaaaaa',fontSize:24}} className="label">Question Paper</label>
            <h5>45</h5>
          </div>
      </div>

      <div className="activity_details">
          <div>
          <label style={{color:'#aaaaaa',fontSize:24}} className="label">Articles</label>
          <h5>60</h5>
          </div>
      </div>

      <div className="activity_details">
          <div>
          <label style={{color:'#aaaaaa',fontSize:24}} className="label">Questions</label>
            <h5>264</h5>
          </div>
      </div>

      <div className="activity_details">
          <div>
          <label style={{color:'#aaaaaa',fontSize:24}} className="label">Referrals</label>
            <h5>02</h5>
          </div>
      </div>

        </div>

      </div>
    </div>
        
    </div>
&nbsp;

<div className="about_section">

    <div className="about_section_details">
      <div className="mainDataTable">
        <label style={{fontSize:32}} className="label">Work</label>
        &nbsp;
        <h5>Grade 8 Maths at JHGFD Middle School, US </h5>
        <label style={{color:'#aaaaaa'}}>Cupidatat laboris minim cillum adipisicing ea enim incididunt. Nulla voluptate non aliqua velit dolor in ea reprehenderit culpa mollit. Velit reprehenderit minim dolor ex tempor do id sunt cupidatat. In Lorem ad pariatur ut adipisicing.</label>
        &nbsp;
     
      </div>
    </div>
    
    <div className="about_section_icons">
    <div className="mainDataTable">
      <FaUserFriends size={20} color="#95a5a6" /> 
      <h5>2019 - Current</h5>
      </div>
  </div>
    
    </div>

    </div>

  );
}

export default Profile;
