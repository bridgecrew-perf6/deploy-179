import React,{useState,useRef, useEffect} from "react";
import Button from 'react-bootstrap/Button';

import Table from 'react-bootstrap/Table';
import Navbar from 'react-bootstrap/Navbar';
import { useNavigate } from "react-router-dom";
import { FaPlus,FaUserAlt} from "react-icons/fa";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';
import './css/create_teacher.css';
import Image from "react-bootstrap/Image";
import onBoard_image from '../assets/onBoard_image.jpg'; 
import Form from 'react-bootstrap/Form';
import Container from 'react-bootstrap/Container';
import './css/animate.min.css';

export default function Create_teacher_online(){

    var navigate = useNavigate();

    return(
        <>

<Navbar bg="light" expand="lg">
  <Container>
    <Navbar.Brand style={{color:'#15424E',fontWeight:'500',fontSize:28}} >Coins For College</Navbar.Brand>
    
  </Container>
</Navbar>

            <div className="body_dash">
        
            <div className="inline_tags">
                <Image src={onBoard_image} style={{height:'100%',borderRadius:110}} resizeMode={"cover"} />    
            </div>

            <div className="inline_tags_2 ">
                <div>
                <h1 style={{color:'#15424E'}} className="fonts heading_fonts">Create Teacher Profile</h1>
                <small style={{opacity:1,color:'#AAAAAA'}} className="fonts">Setup your teacher profile now & get access to create and learn</small>
                &nbsp;

                <hr />        
                <div className="animate__animated animate__fadeInRight">
                
                <div class="form-group">
                 <label for="exampleInputEmail1">Online Teaching Portal Links(Eg.Cousera,Youtube)</label>
                   <input style={{opacity:0.9}} className="form-control" placeholder="Type/Paste the link" />
                </div>

                &nbsp;
                <div style={{padding:10,display:"flex",justifyContent:"space-around"}}>

                    <div style={{width:'49%'}}>
                    <label for="exampleInputEmail1">Subject</label>
                    <input style={{borderRadius:5,borderWidth:0.01,opacity:0.9}} className="form-control" placeholder="Type Your Subject" type="text" name="name" />
                    </div>

                    <div style={{width:'49%'}}>
                    <label for="exampleInputEmail1">Years Of Experience</label>
                        <input style={{borderRadius:5,borderWidth:0.1,opacity:0.9}} className="form-control" placeholder="Type Years Of Experience" type="number"  />
                    </div>

                </div>

                <div style={{marginTop:20}} class="form-group">
                 <label for="exampleInputEmail1">Referred By(Optional)</label>
                   <input style={{opacity:0.9}} className="form-control" placeholder="Type Username/Email Address" />
                </div>

                    <div style={{display:"flex",marginTop:20}}>

                    <div style={{marginRight:10,alignItems:'center'}}>
                        <input style={{height:20,width:20}} type="checkbox"/>
                    </div>

                    <div style={{alignItems:'center'}}>
                        <label style={{color:'#14A9FF'}}><span style={{color:'#AAAAAA'}}>I agree to all the</span> Terms, Privacy policy & Earnings</label>
                    </div>

                </div>
                &nbsp;
                <div style={{padding:10,display:"flex"}}>

                    <div style={{width:'50%'}}>
               
                    </div>

                    <div style={{width:'50%',justifyConten:'flex-end'}}>
                    <Button style={{width:180,backgroundColor:'#14A9FF',borderColor:'#14A9FF'}}>Next</Button>
                    </div>

                </div>
               
                </div>
            </div>

            </div>
            </div>

        </>
    )
}
