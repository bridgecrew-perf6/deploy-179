import React,{useState,useRef, useEffect} from "react";
import Button from 'react-bootstrap/Button';

import Table from 'react-bootstrap/Table';
import Navbar from 'react-bootstrap/Navbar';
import { useNavigate } from "react-router-dom";
import { FaPlus,FaUserAlt} from "react-icons/fa";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';
import './css/create_teacher.css';
import Image from "react-bootstrap/Image";
import onBoard_image from '../assets/onBoard_image.jpg'; 
import Form from 'react-bootstrap/Form';
import Container from 'react-bootstrap/Container';
import './css/animate.min.css';
import $ from "jquery";

export default function Create_teacher_index(){

    var navigate = useNavigate();

    var [fname,setFname] = useState();
    var [lname,setLname] = useState();
    var [email,setEmail] = useState();
    var [password,setPassword] = useState();
    var [radioValue,setRadioValue] = useState();
    var [onlineEducator,setOnlineEducator] = useState(false);
    var [schoolEducator,setSchoolEducator] = useState(false);

    function Submit(){
        if(radioValue == "Online"){
            navigate('/Create_teacher_online');
        
        }
        else if(radioValue == "School"){
            navigate('/Create_teacher_school');
        }
        else{
            alert("You have`t selected anything");
        }
    }

    return(
        <>

<Navbar bg="light" expand="lg">
  <Container>
    <Navbar.Brand style={{color:'#15424E',fontWeight:'500',fontSize:28}} >Coins For College</Navbar.Brand>
    
  </Container>
</Navbar>

            <div className="body_dash">
        
            <div className="inline_tags animate__animated animate__fadeInLeft">
                <Image src={onBoard_image} style={{height:'100%',borderRadius:110}} resizeMode={"cover"} />    
            </div>

            <div className="inline_tags_2 animate__animated animate__fadeInRight">
                <div>
                <h1 style={{color:'#15424E'}} className="fonts heading_fonts">Create Teacher Profile.</h1>
                <small style={{opacity:1,color:'#AAAAAA'}} className="fonts">Setup your teacher profile now & get access to create and learn</small>
                &nbsp;

                <hr />        

                <form>

                <div className="borderMain" style={{marginTop:20}}>
                <h5 style={{fontWeight:'bold',fontSize:20}} className="fonts">Are You :-</h5>
                &nbsp;
                <div className="Radio_Button">
                    <div style={{width:'50%',display:"flex",justifyContent:'center',alignItems:"center"}}>
                       <label>Online Educator</label>
                   </div>

                   <div style={{width:'50%',display:"flex",justifyContent:"flex-end"}}>
                   <Form.Check 
                   className={"Radio"}
                    type={"radio"}
                    checked={onlineEducator}
                      onClick={()=>{ 
                        setRadioValue("Online");  
                        setOnlineEducator(true);
                        setSchoolEducator(false);
                    }}
                    />
                   </div>

                </div>
                &nbsp;
                <div className="Radio_Button">
                    <div style={{width:'50%',display:"flex",justifyContent:'center',alignItems:"center"}}>
                    <label>School Educator</label>
                   </div>

                   <div style={{width:'50%',display:"flex",justifyContent:"flex-end"}}>
                   <Form.Check
                    className={"Radio"}
                    type={"radio"}
                    checked={schoolEducator}
                    onClick={()=>{ 
                        setRadioValue("School");
                        setSchoolEducator(true);
                        setOnlineEducator(false);
                    }}
                     />
                   </div>

                </div>
                
                </div>        

                &nbsp;
                <div style={{padding:10,display:"flex",justifyContent:"space-around"}}>

                    <div style={{width:'45%'}}>
                    <label  className="fonts">First Name.</label>
                    <input className="form-control" style={{borderRadius:5,borderWidth:0.01,opacity:0.5}} placeholder="Type Your First Name" type="text" name="name" onChangeText={(val)=>{ 
                            setFname(val.target.value);
                    }} />
                    </div>

                    <div style={{width:'45%'}}>
                        <label  className="fonts">Last Name.</label>
                        <input className="form-control" style={{borderRadius:5,borderWidth:0.1,opacity:0.5}} placeholder="Type Your Last Name" type="text" onChange={(val)=>{ 
                            setLname(val.target.value);
                    }} />
                    </div>

                </div>

                &nbsp;
                <div style={{padding:10,display:"flex",justifyContent:"space-around"}}>

                    <div style={{width:'49%'}}>
                    <label  className="fonts">Email.</label>
                    <input className="form-control" style={{borderRadius:5,borderWidth:0.1,opacity:0.5,marginRight:25}}  type="text" placeholder="Type Your Email" name="name" onChange={(val)=>{ 
                            setEmail(val.target.value);
                    }} />
                    </div>

                    <div style={{width:'49%'}}>
                        <label className="fonts">Password.</label>
                        <input className="form-control" style={{borderRadius:5,borderWidth:0.1,opacity:0.5}}  placeholder="Type Your Password" type="password"  onChange={(val)=>{ 
                            setPassword(val.target.value);
                    }} />
                    </div>

                </div>
                &nbsp;
                <div style={{padding:10,display:"flex"}}>

                    <div style={{width:'50%'}}>
               
                    </div>

                    <div style={{width:'50%',justifyConten:'flex-end'}}>
                    <Button onClick={Submit} style={{width:180,backgroundColor:'#14A9FF',borderColor:'#14A9FF'}}>Next</Button>
                    </div>

                </div>
               </form>
                </div>
            </div>

            </div>

        </>
    )
}
