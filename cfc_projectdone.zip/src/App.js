  import React,{useState,useRef, useEffect} from "react";
  import Button from 'react-bootstrap/Button';
  import Table from 'react-bootstrap/Table';
  import Navbar from 'react-bootstrap/Navbar';
  import { useNavigate } from "react-router-dom";
  import { FaPlus,FaUserAlt,FaCoins,FaUserFriends} from "react-icons/fa";
  import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip,ResponsiveContainer } from 'recharts';
  import Image from "react-bootstrap/Image";
  import Form from 'react-bootstrap/Form';
  import Container from 'react-bootstrap/Container';
  import Header from "./header";
  import './App.css';
  import './assets/css/dashboard.css';

  function App() {

    const data = [{name: 'Page A', uv: 100, pv: 2400, amt: 2400},{name: 'Page A', uv: 200, pv: 2800, amt: 2200},{name: 'Page A', uv: 300, pv: 1800, amt: 300},{name: 'Page A', uv: 4000, pv: 2800, amt: 3000},{name: 'Page A', uv: 500, pv: 2800, amt: 3000},{name: 'Page A', uv: 600, pv: 2800, amt: 3000},{name: 'Page A', uv: 600, pv: 2800, amt: 8000},{name: 'Page A', uv: 600, pv: 2800, amt: 1000}];

      const renderCustomAxisTick = ({ x, y, payload }) => {
          let path = '';
        switch (payload.value) {
            case 'Sunday':
              path = '';
              break;
            case 'Wednesday':
              path = '';
              break;

            default:
              path = '';
          }
      }

    return (
      <div className="body">
        <Header />
        &nbsp;

        <div className="chartJsDiv">

        <div className="Earning_Progress">

        <div className="Earning_Progress_Item_1">
          <label style={{margin:30,fontSize:25}} className="label">Earnings Progress</label>
        </div>

        <div className="Earning_Progress_Item_2">
        <label style={{margin:30,color:'#F7941D'}} className="label">This Week</label>
        </div>

        </div>

      <div className="mainChartjs"> 

      <ResponsiveContainer width="100%" height="80%">
        <LineChart data={data}>
        <Line type="monotone" dataKey="uv" stroke="#14A9FF" strokeWidth={3} />
        <CartesianGrid stroke="#ccc" strokeDasharray="1 1" />
        <XAxis  axisLine={false} tick={renderCustomAxisTick} />
        <YAxis axisLine={false} />
        <Tooltip />
        </LineChart>
        </ResponsiveContainer>
    </div>

      </div>
      &nbsp;
    
    <div className="bodyTable">

        <div className="body_main">

        <div className="question_paper_div">

        <div className="question_paper_div_contents">

        <div className="cards_tags">

          <div className="CardsContent label">
          <label style={{fontSize:20}}>Individual Questions</label>
          &nbsp;
        
          {/* First Page */}
          <div className="bars_data">
          {/* first Page */}
          <div className="bars_data_content_1">
            <label className="label" style={{fontSize:20,padding:10}}>Total Question Created</label>
          </div>
          {/* Second Page */}
          <div className="bars_data_content_2">
          <label className="label" style={{fontSize:20,padding:10}}>28</label>
          </div>

          </div>

          &nbsp;
        
        {/* First Page */}
        <div className="bars_data_2">
        {/* first Page */}
        <div className="bars_data_content_1">
          <label className="label" style={{fontSize:20,padding:10}}>Coins Earned</label>
        </div>
        {/* Second Page */}
        <div className="bars_data_content_2">
        <label className="label" style={{fontSize:20,padding:10}}>120</label>
        </div>

        </div>
          
          </div>

        </div>

    </div>

    <div className="question_paper_div_contents">
    
    <div className="cards_tags">

  <div className="CardsContent label">
  <label style={{fontSize:20}}>Questions Paper</label>
  &nbsp;

  {/* First Page */}
  <div className="bars_data">
  {/* first Page */}
  <div className="bars_data_content_1">
    <label className="label" style={{fontSize:20,padding:10}}>Total Question Created</label>
  </div>
  {/* Second Page */}
  <div className="bars_data_content_2">
  <label className="label" style={{fontSize:20,padding:10}}>28</label>
  </div>

  </div>

  &nbsp;

  {/* First Page */}
  <div className="bars_data_2">
  {/* first Page */}
  <div className="bars_data_content_1">
  <label className="label" style={{fontSize:20,padding:10}}>Coins Earned</label>
  </div>
  {/* Second Page */}
  <div className="bars_data_content_2">
  <label className="label" style={{fontSize:20,padding:10}}>120</label>
  </div>

  </div>

  </div>

  </div>

    </div>

        </div>

  &nbsp;
  {/* Question Paper Staert */}

  <div className="question_paper_Main">

      <div style={{padding:'3%'}}>

      <div>
        <h4>Question Bank</h4>
        <small style={{color:'#AAAAAA'}}>You have recently added an individual question</small>
      </div>
      <hr />
      
      <div className="Question_bank">

      <label className="label">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eget magna felis. sectetur adipiscing elit. Eget magna felis. Eget magna felis.  consectetur adipis </label>
      &nbsp;

      <div className="mcq_data">

      <div className="mcq_data_contents">
        <label className="label mcq_unhighlight">Option A 12</label>
      </div>

      <div  className="mcq_data_contents">
        <label className="label mcq_unhighlight">Option B 12</label>
      </div>

      <div  className="mcq_data_contents">
        <label  className="label mcq_unhighlight">Option C 12</label>
      </div>

      <div  className="mcq_data_contents">
        <label  className="label mcq_unhighlight">Option D 12</label>
      </div>

      <div  className="mcq_data_contents">
        
      </div>

      <div  className="mcq_data_contents">
          <label className="mcq_highlight ">10</label>
      </div>

      <div  className="mcq_data_contents">
        <label  className="mcq_highlight">Physics</label>
      </div>

      <div  className="mcq_data_contents">
        <label  className="mcq_highlight">Friction</label>
      </div>

      </div>

      </div>

      <div className="viewAllTag">
        <label className="view_all_text">View all</label>
      </div>

      </div>

  </div>

      </div>

      <div className="body_Referals">

      <div className="body_Referals_body">

      <div className="referal_top_bar">

  <div className="top_con_1">
    <label style={{fontSize:20}} className="label">Referals</label>      
    </div>
    <div className="top_con_2">
    <label style={{color:'rgba(20, 169, 255, 1)'}} className="label">View All</label>      
    </div>

      </div>

    {/* Button Tags */}
      <div className="referal_top_bar">
        
      <div className="button_top_bar_content_1">
        <div className="Item_Content">
          <FaUserFriends size={20} color="#95a5a6" /> 
          </div>

          <div className="Item_Content">
          <label className="label">20</label>
          </div>
      </div>

      <div className="button_top_bar_content_2">
        <div className="Item_Content">
          <FaCoins size={20} color="#95a5a6" /> 
          </div>

          <div className="Item_Content">
          <label className="label">20</label>
          </div>
      </div>
  </div>

  <div className="cards_tags_1">
  <div className="cards_top_bar_content">
    <div className="cards_top_1">
          <FaUserAlt size={25} color="rgba(242, 47, 47, 0.5)" /> 
          </div>
          <div className="cards_top_2">
          <label style={{fontSize:18}} className="label">Inactive users</label>
          </div>
    </div>

  <label>Image Area</label>

  <div className="viewAll">
  <div>
    <label className="btnPing">Ping All</label>
  </div>

  </div>
  &nbsp;
  </div>
  &nbsp;
  <div className="cards_tags_1">
  <div className="cards_top_bar_content">
    <div className="cards_top_1">
          <FaUserAlt size={25} color="rgba(242, 47, 47, 0.5)" /> 
          </div>
          <div className="cards_top_2">
          <label style={{fontSize:18}} className="label">active users</label>
          </div>
    </div>
    <label>Image Area</label>
  <div className="viewAll">
  <div>
    <label className="btnView">View All</label>
  </div>

  </div>
  &nbsp;
  </div>

      </div>

      </div>

      </div>

      </div>

    );
  }

  export default App;
